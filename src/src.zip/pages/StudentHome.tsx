import React, { useContext, useEffect, useState } from "react";
import "../assets/styles.css";
import {
  Box,
  Card,
  CardContent,
  CircularProgress,
  IconButton,
  Stack,
  Typography,
} from "@mui/material";
import { ExerciseTable } from "../components/ExerciseTable";
import { ErrorSpring, ExerciseHome, LoginTypes } from "../Types";
import { enqueueSnackbar } from "notistack";
import { Add, Forum, Refresh } from "@mui/icons-material";
import { MyBreadcrumbs } from "../components/navigation/MyBreadcrumbs";
import { LoginContext } from "../Utils";
import { useNavigate } from "react-router-dom";
import { DateTime } from "luxon";
import { Link } from "../components/navigation/Link";

export function StudentHome() {
  const [isLoading, setIsLoading] = useState(true);
  const [globalError, setGlobalError] = useState<string | null>(null);
  const [data, setData] = useState<Map<string, ExerciseHome[]>>(new Map());

  const loginStatus: LoginTypes = useContext(LoginContext);
  const navigate = useNavigate();

  function refresh() {
    setIsLoading(true);
  }

  useEffect(() => {
    if (isLoading) {
      const fetchExercises = async () => {
        try {
          const response = await fetch("http://localhost:8080/exercises", {
            method: "GET",
            credentials: "include",
          });

          if (response.status === 401) {
            loginStatus.setIsLogged(false);
            navigate("/login");
            return;
          } else if (!response.ok) {
            const contentType = response.headers.get("content-type");
            if (contentType && contentType.indexOf("application/json") !== -1) {
              const errorExercise: ErrorSpring = await response.json();
              setIsLoading(false);
              throw new Error("Error from backend - " + errorExercise.message);
            } else {
              setIsLoading(false);
              throw new Error("Error from backend - " + response.status);
            }
          }

          const exercises: ExerciseHome[] = await response.json();

          const batteries = new Map<string, ExerciseHome[]>(
            exercises.map((exercise) => [exercise.batteryName, []])
          );

          exercises.forEach((exercise) => {
            //The automatic parse doesn't know this is a DateTime, so it just parses it as String, so I parse it myself
            const creationDate = exercise.creationTimestamp.toString();
            exercise.creationTimestamp = DateTime.fromISO(creationDate);

            batteries.get(exercise.batteryName)?.push(exercise);
          });

          setData(batteries);
          setGlobalError(null);
        } catch (error: any) {
          setGlobalError(
            "There was a problem fetching the data:\n" + error.message
          );
          console.log(
            "There was a problem fetching the data:\n" + error.message
          );
        }
        setIsLoading(false);
      };
      void fetchExercises();
    }
  }, [isLoading, loginStatus, navigate]);

  const handleFavRow = (exercise: ExerciseHome, index: number) => {
    const updateFavorite = async () => {
      try {
        const response = await fetch(
          "http://localhost:8080/users/favorites/" + exercise.id,
          {
            method: "PATCH",
            credentials: "include",
          }
        );

        if (response.status === 401) {
          loginStatus.setIsLogged(false);
          navigate("/login");
          return;
        } else if (!response.ok) {
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            const errorExercise: ErrorSpring = await response.json();
            throw new Error("Error from backend - " + errorExercise.message);
          } else {
            throw new Error("Error from backend - " + response.status);
          }
        }

        exercise.favorite = !exercise.favorite;
        const newMap = new Map(data);

        const exerciseList = [...(newMap.get(exercise.batteryName) ?? [])];
        exerciseList[index] = exercise;
        newMap.set(exercise.batteryName, exerciseList);

        setData(newMap);

        enqueueSnackbar(
          `${exercise.name}` +
            (exercise.favorite
              ? " set as favorite"
              : " removed from favorites"),
          {
            variant: "success",
          }
        );
      } catch (err: any) {
        const error =
          `${exercise.name}` +
          (exercise.favorite
            ? " could not be set as favorite"
            : " could not be removed from favorites");
        console.log(error + ", " + err.message);
        enqueueSnackbar(error, {
          variant: "error",
        });
      }
    };
    void updateFavorite();
  };

  let content;

  if (isLoading) {
    content = <CircularProgress />;
  } else if (globalError) {
    content = (
      <Card
        className="flex-center"
        sx={{
          width: "40%",
        }}
      >
        <CardContent>
          <Typography>{globalError}</Typography>
        </CardContent>
      </Card>
    );
  } else if (data.size === 0) {
    const txt = "There is no exercises yet!\nAsk Penin ᕕ(⌐■_■)ᕗ ♪♬";
    content = (
      <>
        <Typography whiteSpace="pre-line" variant="h5">
          {txt}
        </Typography>
      </>
    );
  } else {
    content = (
      <Stack sx={{ width: "75%" }}>
        <Box display="flex">
          <Box justifyContent="left" display="flex" sx={{ flexGrow: 1 }}>
            <IconButton color="primary" onClick={refresh}>
              <Refresh />
              <Typography marginLeft="6px"> Reload</Typography>
            </IconButton>
          </Box>
          <Box sx={{marginBottom: 1}} justifyContent="right" display="flex">
            <IconButton
              component={Link}
              to="/exercises/new"
              color="primary"
              size="small"
              sx={{
                border: "1px solid",
                borderColor: "primary.main",
                borderRadius: "8px",
                padding: "6px 12px",
              }}
            >
              <Typography variant="button" color="primary">
                New Exercise
              </Typography>
            </IconButton>
          </Box>
        </Box>
        <Card sx={{ padding: "1%" }}>
          <CardContent>
            <Stack spacing={10} direction="column">
              {Array.from(data.keys()).map((battery) => (
                <ExerciseTable
                  key={battery}
                  batteryName={battery}
                  exercises={data.get(battery) ?? []}
                  onFavRow={handleFavRow}
                />
              ))}
            </Stack>
          </CardContent>
        </Card>
      </Stack>
    );
  }

  return (
    <>
      <MyBreadcrumbs />
      <div className="centered-mt">{content}</div>
    </>
  );
}
