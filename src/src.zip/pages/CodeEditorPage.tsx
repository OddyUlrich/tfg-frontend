import React, { useEffect, useRef, useState } from "react";
import {
  MonacoEditor,
  RangeRestrictionObject
} from "../components/MonacoEditor";
import { MyBreadcrumbs } from "../components/navigation/MyBreadcrumbs";
import {
  CodeEditorData,
  ErrorSpring,
  ExerciseFile,
  MyTreeNode
} from "../Types";
import { useLocation, useParams } from "react-router-dom";
import { Allotment } from "allotment";
import { createTree, FileTree } from "../components/tree/FileTree";
import { Box, CircularProgress, Switch } from "@mui/material";
import { TreeStructure } from "../TreeStructure";
import { MyTab } from "../components/EditorTabs";
import { editor, Uri } from "monaco-editor";
import { Monaco } from "@monaco-editor/react";
import { constrainedEditor } from "constrained-editor-plugin";
import { AlertDialog } from "../components/dialogs/AlertDialog";
import Typography from "@mui/material/Typography";
import SaveIcon from "@mui/icons-material/Save";
import DownloadOutlinedIcon from "@mui/icons-material/DownloadOutlined";
import Button from "@mui/material/Button";
import FolderZipIcon from "@mui/icons-material/FolderZip";
import SendIcon from "@mui/icons-material/Send";
import { Done } from "@mui/icons-material";
import { enqueueSnackbar } from "notistack";

export function CodeEditorPage() {
  const location = useLocation();
  const [openSaveDialog, setOpenSaveDialog] = React.useState(false);
  const [exerciseName, setExerciseName] = useState<string>();
  const [currentSolutionId, setCurrentSolutionId] = useState<string | null>(
    null
  );
  const [batteryName, setBatteryName] = useState<string>();
  const [templateFiles, setTemplateFiles] = useState<ExerciseFile[]>();
  const [tabs, setTabs] = useState<MyTab[]>([]);
  const [activeTab, setActiveTab] = useState<number>(0);
  const [parentsIdList, setParentsIdList] = useState<string[]>([]);
  const [unsavedChanges, setUnsavedChanges] = useState<boolean>(false);
  const [autosave, setAutosave] = useState<boolean>(true);
  const [isButtonSmall, setIsButtonSmall] = useState<boolean>(false);
  const [fileTree, setfileTree] = useState<TreeStructure>();
  const [rootNode, setRootNode] = useState<MyTreeNode>({
    nodeId: "0",
    label: "Exercise",
    file: null,
    children: []
  });

  //Code editor variables
  const editorRef = useRef<editor.IStandaloneCodeEditor | null>(null);
  const restrictions: RangeRestrictionObject[] = [];

  //Route params
  const { exerciseId } = useParams<{exerciseId: string}>();

  //Separations
  const handleAllotmentChange = (sizes: number[]) => {
    sizes[2] < 325 ? setIsButtonSmall(true) : setIsButtonSmall(false);
  };

  //Dialog handlers
  const handleDialogClose = () => {
    setOpenSaveDialog(false);
  };

  const handleDialogOpen = () => {
    setOpenSaveDialog(true);
  };

  //Fetching files for the editor to show and setting up states and file tree
  useEffect(() => {

    const fetchData = async () => {
      try {
        const response = await fetch(
          `http://localhost:8080/exercises/${exerciseId}/solutions`,
          {
            method: "GET",
            credentials: "include"
          }
        );

        if (!response.ok) {
          const errorExercise: ErrorSpring = await response.json();
          throw new Error("Error from backend - " + errorExercise.message);
        }

        const data: CodeEditorData = await response.json();
        setExerciseName(data.exercise.name);
        setBatteryName(data.exercise.nameFromBattery);
        setTemplateFiles(data.templateFiles);
        setCurrentSolutionId(data.currentSolution);

        const filesForDisplay = data.filesForDisplay;

        const root: MyTreeNode | null = {
          nodeId: "0",
          label: "Exercise",
          file: null,
          children: []
        };

        const myTree = new TreeStructure();
        myTree.addNode(root);

        //Nodos a expandir (padres)
        const parentNodeIdList: string[] = [root.nodeId];

        createTree(myTree, filesForDisplay, root, parentNodeIdList);

        setRootNode(root);
        setfileTree(myTree);
        setParentsIdList(parentNodeIdList);

      } catch (error: any) {
        console.log("Network error: " + error.message);
      }
    };
    void fetchData();
  }, [location.pathname]);

  const handleSave = (buttonPressed: boolean) => {
    const displayFiles: Array<ExerciseFile> = [];
    fileTree?.filterSolutionNodes(displayFiles);

    displayFiles.forEach((file) => {
      const model = editor.getModel(Uri.parse(file.path));
      if (model) {
        file.text = model.getValue();
      }
    });

    const saveData = async () => {
      try {
        const response = await fetch(`http://localhost:8080/exercises/${exerciseId}/solutions`, {
          method: "POST",
          body: JSON.stringify({
            filesForDisplay: displayFiles,
            exerciseId: exerciseId,
            solutionId: currentSolutionId
          }),
          headers: {
            "Content-Type": "application/json"
          },
          credentials: "include"
        });

        if (!response.ok) {
          const errorExercise: ErrorSpring = await response.json();
          throw new Error("Error from backend - " + errorExercise.message);
        }

        setUnsavedChanges(false);

        if (buttonPressed) {
          enqueueSnackbar("Se ha guardado todo correctamente", {
            variant: "success"
          });
        }


      } catch (error: any) {
        if (error instanceof Error) {
          console.log(error.message);
        }
      }
    };
    void saveData();
  };

  //Auto-save handle (3 seconds)
  const saveTimeout = useRef<NodeJS.Timeout | null>(null);

  const handleEditorChange = (content: string | undefined) => {
    const tab = tabs[activeTab];

    if (tab && tab.node.file && content) {
      const path = Uri.parse(tab.node.file.path);
      editor.getModel(path)?.setValue(content);
    }

    setUnsavedChanges(true);

    if (!autosave) return;

    if (saveTimeout.current) {
      clearTimeout(saveTimeout.current);
    }

    saveTimeout.current = setTimeout(() => {
      handleSave(false);
    }, 3000);

  };

  //Clean-up function so no timeout lasts even in page changes
  useEffect(() => {
    return () => {
      if (saveTimeout.current) {
        clearTimeout(saveTimeout.current);
      }
    };
  }, []);

  const handleStatusAutosave = (event: React.ChangeEvent<HTMLInputElement>) => {
    setAutosave(event.target.checked);
  };

  const handleTabClick = (event: React.SyntheticEvent, index: number) => {
    setActiveTab(index);
  };

  const handleCloseTab = (
    event: React.MouseEvent<HTMLElement>,
    index: number
  ) => {
    event.stopPropagation();


    const newTabs = [...tabs];
    if (index > -1) {
      newTabs.splice(index, 1);
    }

    if (activeTab === tabs.length - 1 && activeTab > 0) {
      setActiveTab(activeTab - 1);
    }

    setTabs(newTabs);
  };


  function handleEditorDidMount(
    codeEditor: editor.IStandaloneCodeEditor,
    monaco: Monaco
  ) {
    editorRef.current = codeEditor;

    const constrainedInstance = constrainedEditor(monaco);
    const model = codeEditor.getModel();

    constrainedInstance.initializeIn(codeEditor);
     restrictions.push({
       range: [1, 1, 2, 10],
       allowMultiline: true,
     });
     constrainedInstance.addRestrictionsTo(model, restrictions);
  }

  //Function for handling the event of selecting a node from the tree
  const handleNodeSelect = (
    _event: React.SyntheticEvent | null,
    nodeId: string | null
  ) => {

    //We don't check the event cause this function could be called by a component and not the user

    if (fileTree === undefined || nodeId === null) {
      console.warn("Tree not declared");
      return;
    }

    const selectedNode = fileTree.findNodeById(nodeId);

    //If the selected node is not a file, it does nothing
    if (!selectedNode?.file) {
      return;
    }


    const newTabs = [...tabs];

    //If the selected node already has a corresponding tab, it does nothing
    for (let i = 0; i < tabs.length; i++) {
      if (tabs[i].node.nodeId === nodeId) {
        setActiveTab(i);
        return;
      }
    }

    //Create a new tab with the selected node to show the file
    const newTab: MyTab = {
      node: selectedNode
    };

    //If the model already exist for that file, it will use it, if not, it will create a new one with the file content
    const model = editor.getModel(Uri.parse(selectedNode.file.path));

    if (!model) {

      editor.createModel(
        selectedNode.file.text,
        "java",
        Uri.parse(selectedNode.file.path)
      );
    }

    //Now we add the new tab in the list of tabs
    newTabs.push(newTab);
    setTabs(newTabs);

    //Select this new tab to show the content instantly
    setActiveTab(newTabs.length - 1);
  };

  //Upload the solution files to get a correction and a number of errors
  const handleSubmit = () => {
    //TODO ENVIAR NODOS DEL ÁRBOL (SOLO DE SOLUCIÓN)
  };

  let saveStatusIcon;
  if (autosave && unsavedChanges) {
    saveStatusIcon = <CircularProgress sx={{ marginRight: "5px" }} size={24} />;
  } else if (autosave && !unsavedChanges) {
    saveStatusIcon = <Done sx={{ marginRight: "5px" }} color="success" />;
  } else {
    saveStatusIcon = null;
  }


  return (
    <>
      <AlertDialog open={openSaveDialog} handleClose={handleDialogClose} />
      <Box sx={{ display: "flex", justifyContent: "space-between" }}>
        <MyBreadcrumbs exerciseName={exerciseName} batteryName={batteryName} />
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            marginRight: "25px",
            marginTop: "10px"
          }}
        >
          <Button
            sx={{ marginRight: "20px" }}
            color="primary"
            variant="contained"
            onClick={() => handleSave(true)}
          >
            <Typography variant="button">
              <strong>SAVE ALL</strong>
            </Typography>
          </Button>
          {saveStatusIcon}
          <SaveIcon sx={{ mr: 0.5 }} fontSize="medium" />
          <Typography variant="button">
            <strong>AUTOSAVE</strong>
          </Typography>
          <Switch onChange={handleStatusAutosave} checked={autosave} />
        </Box>
      </Box>
      <Box className="editor-page">
        <Allotment onChange={handleAllotmentChange}>
          <Allotment.Pane minSize={150} snap>
            <Box>{rootNode?.label}</Box>

            <Button
              onClick={handleSubmit}
              color="success"
              variant="contained"
              endIcon={<SendIcon />}
            >
              <Typography variant="button">
                <strong>Submit solution</strong>
              </Typography>
            </Button>
          </Allotment.Pane>
          <Box padding="0px 20px 0px 20px">
            <Allotment.Pane visible snap>
              <MonacoEditor
                path={tabs[activeTab]?.node.file?.path ?? "/"}
                tabs={tabs}
                activeTab={activeTab}
                onTabClick={handleTabClick}
                onCloseClick={handleCloseTab}
                onValueChange={handleEditorChange}
                onEditorDidMount={handleEditorDidMount}
              />
            </Allotment.Pane>
          </Box>
          <Allotment.Pane preferredSize="25%" minSize={150} snap>
            <Box className="file-pane">
              <Box className="file-selector"
              >
                <FileTree
                  expand={true}
                  onNodeSelect={handleNodeSelect}
                  parents={parentsIdList}
                  nodeId={rootNode?.nodeId}
                  label={rootNode?.label}
                  children={rootNode?.children}
                />
                <Box
                  className="download-buttons"
                >
                  <Button
                    sx={{ borderRadius: "5px" }}
                    color="primary"
                    variant="contained"
                    startIcon={<DownloadOutlinedIcon />}
                  >
                    <Typography sx={{ fontWeight: "bold" }}
                                variant="button">{!isButtonSmall ? "Download File" : "File"}</Typography>
                  </Button>
                  <Button
                    sx={{ borderRadius: "5px" }}
                    color="primary"
                    variant="contained"
                    startIcon={<FolderZipIcon />}>
                    <Typography sx={{ fontWeight: "bold" }}
                                variant="button"> {!isButtonSmall ? "Download All" : "All"}</Typography>
                  </Button>
                </Box>
              </Box>
            </Box>
          </Allotment.Pane>
        </Allotment>
      </Box>
    </>
  );
}
