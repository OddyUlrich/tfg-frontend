import * as React from "react";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import TextField from "@mui/material/TextField";
import { useEffect } from "react";

interface AlertDialogProps {
  open: boolean;
  handleClose: (confirmed: boolean, inputValue?: string) => void;
  varType: string;
}

export const AddRuleDialog: React.FC<AlertDialogProps> = ({open, handleClose, varType}:AlertDialogProps) => {

  const [ruleName, setRuleName] = React.useState("");

  useEffect(() => {
    if (!open) {
      setRuleName("");
    }
  }, [open]);


  return (
    <div>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle id="alert-dialog-title">
          {"Añadir nueva regla"}
        </DialogTitle>

        <DialogContent>
          {["int","double","float","long","short","boolean","byte"].includes(varType) ? (
            <>
              ¿Qué nombre quieres que tenga la variable <strong>{varType}</strong>?
            </>
          ) : (
            <>
              ¿Qué nombre quieres que tenga la variable relacionado con el <strong>{varType}</strong>?
            </>
          )}
          <TextField
            sx={{ marginTop: 4, width: "100%" }}
            margin="normal"
            variant={"outlined"}
            required
            fullWidth
            id="ruleName"
            label="Name"
            name="ruleName"
            autoComplete="ruleName"
            autoFocus
            value={ruleName}
            onChange={(e) => setRuleName(e.target.value)}
          />
        </DialogContent>

        <DialogActions>
          <Button onClick={() => handleClose(false)}>
            Cancelar
          </Button>
          <Button onClick={() => handleClose(true, ruleName)} autoFocus>
            Añadir
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
};